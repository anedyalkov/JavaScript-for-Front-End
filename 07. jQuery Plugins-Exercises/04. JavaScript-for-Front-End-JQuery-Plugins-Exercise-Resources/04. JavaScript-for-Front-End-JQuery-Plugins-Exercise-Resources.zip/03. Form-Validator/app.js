$.validate({
    lang:'en',
    modules:'security',
    addValidClassOnAll: true,
})